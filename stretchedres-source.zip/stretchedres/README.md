# stretchedres+

A client-side Fabric mod for Minecraft that gives you a stretched resolution:
the world is drawn at a narrower aspect ratio (default 4:3) and stretched across
your window, so everything looks wider. Handy for PvP, bridging and Bedwars.

## Controls

| Key | Action |
| --- | --- |
| `G` | Toggle stretch on/off |
| `]` | More stretch |
| `[` | Less stretch |

All three can be rebound in Options > Controls. Settings are saved in
`config/stretchedres.properties` (`aspect`: lower number = more stretch).

## Builds

One jar per Minecraft version range. Needs Fabric Loader and Fabric API.

| Jar | Minecraft | Java |
| --- | --- | --- |
| `stretchedres-mc1.19.2.jar` | 1.19.2 | 17 |
| `stretchedres-mc1.19.3-1.20.4.jar` | 1.19.3 to 1.20.4 | 17 |
| `stretchedres-mc1.20.5-1.21.1.jar` | 1.20.5 to 1.21.1 | 21 |
| `stretchedres-mc1.21.2-1.21.4.jar` | 1.21.2 to 1.21.4 | 21 |

## Status

This source has **not been compiled or run in-game yet**. The first CI run is
the first real build. If a build fails or a version crashes, the likely cause is
the renderer hook in `src/variants/*/java/.../GameRendererMixin.java` (the
method it targets has changed between Minecraft versions), or a Fabric API
version in `versions/*.properties`. Read the failing log and adjust.

## Getting the downloads online

1. Create a GitHub repository (e.g. `stretchedres`) and push this folder to it.
2. GitHub Actions (`.github/workflows/build.yml`) builds all four jars on every push.
3. To publish a release, tag it: `git tag v1.0.0 && git push --tags`.
   The workflow attaches the four jars to a GitHub Release.
4. On the website, set the repo in the Tweaks panel to `YOUR-USER/stretchedres`.
   The download buttons then point at `releases/latest/download/<jar name>`.

## Building locally

Needs JDK 21 and Gradle 8.11+ (Gradle wrapper not included).

```
gradle build -Pmc=1.20.1
```

`-Pmc` is one of `1.19.2`, `1.20.1`, `1.21.1`, `1.21.4` (the files in `versions/`).
The jar ends up in `build/libs/`. To use a specific Fabric API version, add
`-Pfabric_api_override=<version>`.

## How it works

A mixin on `GameRenderer#getProjectionMatrix` multiplies the finished projection
matrix by a horizontal scale of `windowAspect / targetAspect`. The GUI and
mouse input are untouched. The 1.19.2 variant uses Mojang's `Matrix4f`; later
versions use JOML's.

## License

MIT, see `LICENSE`. Not affiliated with Mojang or Microsoft.
