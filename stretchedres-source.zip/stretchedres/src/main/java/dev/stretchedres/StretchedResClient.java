package dev.stretchedres;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class StretchedResClient implements ClientModInitializer {
    private static final String CATEGORY = "category.stretchedres";

    private static KeyMapping toggleKey;
    private static KeyMapping moreKey;
    private static KeyMapping lessKey;

    @Override
    public void onInitializeClient() {
        StretchedResConfig.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.stretchedres.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY));
        moreKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.stretchedres.more", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, CATEGORY));
        lessKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.stretchedres.less", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(StretchedResClient::onTick);
    }

    private static void onTick(Minecraft client) {
        while (toggleKey.consumeClick()) {
            StretchedResConfig.setEnabled(!StretchedResConfig.isEnabled());
            announce(client);
        }
        while (moreKey.consumeClick()) {
            StretchedResConfig.setEnabled(true);
            StretchedResConfig.adjust(-StretchedResConfig.STEP);
            announce(client);
        }
        while (lessKey.consumeClick()) {
            StretchedResConfig.setEnabled(true);
            StretchedResConfig.adjust(StretchedResConfig.STEP);
            announce(client);
        }
    }

    private static void announce(Minecraft client) {
        if (client.player == null) {
            return;
        }
        String message = StretchedResConfig.isEnabled()
                ? String.format(Locale.ROOT, "stretchedres+: ON (aspect %.2f)", StretchedResConfig.getTargetAspect())
                : "stretchedres+: OFF";
        client.player.displayClientMessage(Component.literal(message), true);
    }
}
