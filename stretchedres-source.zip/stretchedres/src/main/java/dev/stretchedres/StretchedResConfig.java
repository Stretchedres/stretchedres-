package dev.stretchedres;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Tiny settings holder, saved to config/stretchedres.properties.
 *
 * The "target aspect" is the aspect ratio the game world is drawn at before
 * it is stretched across your real window. 4:3 (1.33) on a 16:9 window gives
 * the classic wide, "stretched res" look. Lower number = more stretch.
 */
public final class StretchedResConfig {
    public static final double MIN_ASPECT = 0.5;
    public static final double MAX_ASPECT = 4.0;
    public static final double STEP = 0.05;

    private static boolean enabled = true;
    private static double targetAspect = 4.0 / 3.0;

    private StretchedResConfig() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("stretchedres.properties");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) {
            save();
            return;
        }
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
            enabled = Boolean.parseBoolean(props.getProperty("enabled", "true"));
            targetAspect = clamp(Double.parseDouble(props.getProperty("aspect", "1.3333")));
        } catch (IOException | NumberFormatException e) {
            // Bad or unreadable file: keep defaults and rewrite it.
            enabled = true;
            targetAspect = 4.0 / 3.0;
            save();
        }
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("enabled", Boolean.toString(enabled));
        props.setProperty("aspect", String.format(java.util.Locale.ROOT, "%.4f", targetAspect));
        try (OutputStream out = Files.newOutputStream(file())) {
            props.store(out, "stretchedres+ settings (aspect: lower = more stretch)");
        } catch (IOException ignored) {
            // Not fatal: settings just won't persist this time.
        }
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        save();
    }

    public static double getTargetAspect() {
        return targetAspect;
    }

    public static void adjust(double delta) {
        targetAspect = clamp(Math.round((targetAspect + delta) * 100.0) / 100.0);
        save();
    }

    private static double clamp(double value) {
        return Math.max(MIN_ASPECT, Math.min(MAX_ASPECT, value));
    }

    /** Horizontal scale applied to the projection. 1.0 means "no change". */
    public static float scaleX(int windowWidth, int windowHeight) {
        if (!enabled || windowWidth <= 0 || windowHeight <= 0) {
            return 1.0f;
        }
        double windowAspect = (double) windowWidth / (double) windowHeight;
        return (float) (windowAspect / targetAspect);
    }
}
