package dev.stretchedres.mixin;

import dev.stretchedres.StretchedResConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Minecraft 1.19.3 and newer (JOML matrices).
 *
 * Scales the finished projection matrix horizontally. Targeting the method by
 * name only keeps this working across versions where the parameter type
 * changed (double -> float) but the method kept its name.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void stretchedres$stretch(CallbackInfoReturnable<Matrix4f> cir) {
        Minecraft mc = Minecraft.getInstance();
        float sx = StretchedResConfig.scaleX(mc.getWindow().getWidth(), mc.getWindow().getHeight());
        if (sx == 1.0f) {
            return;
        }
        cir.setReturnValue(new Matrix4f().scaling(sx, 1.0f, 1.0f).mul(cir.getReturnValue()));
    }
}
