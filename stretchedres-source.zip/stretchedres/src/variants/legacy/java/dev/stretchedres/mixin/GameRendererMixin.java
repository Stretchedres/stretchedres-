package dev.stretchedres.mixin;

import com.mojang.math.Matrix4f;
import dev.stretchedres.StretchedResConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Minecraft 1.19.2 (Mojang's own Matrix4f, before the switch to JOML).
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void stretchedres$stretch(CallbackInfoReturnable<Matrix4f> cir) {
        Minecraft mc = Minecraft.getInstance();
        float sx = StretchedResConfig.scaleX(mc.getWindow().getWidth(), mc.getWindow().getHeight());
        if (sx == 1.0f) {
            return;
        }
        Matrix4f scale = Matrix4f.createScaleMatrix(sx, 1.0f, 1.0f);
        scale.multiply(cir.getReturnValue());
        cir.setReturnValue(scale);
    }
}
